//package model;
//
//public interface ImagePro extends Image {
//
//  Image sepiaSplit(double perc);
//
//  Image sharpenSplit(double perc);
//
//  Image blurSplit(double perc);
//
//  Image valueSplit(double perc);
//
//  Image lumaSplit(double perc);
//
//  Image intensitySplit(double perc);
//
//  Image compress(double factor);
//
//  /**
//   *
//   * @return
//   */
//  Image createHistogram();
//
//  /**
//   *
//   * @return
//   */
//  Image colorCorrect();
//
//  /**
//   *
//   * @param b_p
//   * @param m_p
//   * @param w_p
//   * @return
//   */
//  Image adjustLevels(int b_p, int m_p, int w_p);
//}
